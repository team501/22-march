/**
 * @fileOverview Legend component.
 * Orchestrates all rendering each LegendItem component,
 * based on each item.
 * @name Legend.js
 * @license MIT
 */
import React, { Component } from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';

import LegendItem from './LegendItem';
import TotalLegend from './TotalLegend';

/**
 * @extends {Component}
 */
export default class Legend extends Component {
    /* React render function */
    render() {
        const {
            className, data, strokeColor, emptyColor, colorFunction, colors,
            width, totalWidth, onClick, onMouseEnter, toggleSelect, selected, totalLabel
        } = this.props;

        const legendItemClassName = `${className}-item`;
       
       const totalValue = this.props.total;

        return <g
            className={ className }>
            <TotalLegend
                key={ `legenditem${1}` }
                index={ 1 }
                item={ {
                    label: totalLabel,
                    value: totalValue
                } }
                className={ className }
                width={ width }
                totalWidth={ totalWidth }
            />
            { data.map((item, index) => {
                const classes = {};
                const { isEmpty, className } = item;
                // let stroke = strokeColor;
                let opacity = 1;

                if (isEmpty) {
                    classes.empty = true;
                    // stroke = emptyColor;
                } else if (selected.label === item.label) {
                    if (toggleSelect) {
                        classes.toggled = true;
                        opacity = 0.85;
                    } else {
                        classes.selected = true;
                        opacity = 1;
                    }
                }

                if (className) {
                    classes[className] = true;
                }

                classes[legendItemClassName] = true;

                const fill = isEmpty ? emptyColor : colorFunction(colors, index);
                const stroke = isEmpty ? emptyColor : colorFunction(colors, index);

                return (
                    <LegendItem
                        key={ `legenditem${index}` }
                        index={ index }
                        item={ item }
                        className={ classnames(classes) }
                        width={ width }
                        totalWidth={ totalWidth }
                        opacity={ opacity }
                        fill= { fill }
                        stroke={ stroke }
                        onClick={ onClick }
                        onMouseEnter={ onMouseEnter }
                    />
                );
            }) }
        </g>;
    }
}

Legend.propTypes = {
    data: PropTypes.arrayOf(PropTypes.shape({
        percent: PropTypes.number.isrequired,
        label: PropTypes.string.isrequired,
        className: PropTypes.string,
        isEmpty: PropTypes.boolean
    })).isRequired,
    selected: PropTypes.shape({
        percent: PropTypes.number.isRequired,
        label: PropTypes.string.isRequired,
        className: PropTypes.string,
        isEmpty: PropTypes.boolean
    }).isRequired,
    total: PropTypes.number.isRequired,
    toggleSelect: PropTypes.bool.isRequired,
    colorFunction: PropTypes.func.isRequired,
    onMouseEnter: PropTypes.func.isRequired,
    onClick: PropTypes.func.isRequired,
    width: PropTypes.number.isRequired,
    totalWidth: PropTypes.number.isRequired,
    className: PropTypes.string,
    colors: PropTypes.arrayOf(PropTypes.string),
    emptyColor: PropTypes.string,
    strokeColor: PropTypes.string
};

Legend.defaultProps = {
    data: [{
        label: 'Default',
        percent: 0,
        value: 0,
        isEmpty: true,
    }],
    selected: {
        percent: 100,
        label: 'Default',
        value: 0,
    },
    total: 0,
    toggleSelect: false,
    className: 'donutchart-legend',
    width: 250,
    totalWidth: 750,
    colors: ['#f44336', '#e91e63', '#9c27b0',
        '#673ab7', '#3f51b5', '#2196f3',
        '#03a9f4', '#00bcd4', '#009688',
        '#4caf50', '#8bc34a', '#cddc39',
        '#ffeb3b', '#ffc107', '#ff9800',
        '#ff5722', '#795548', '#607d8b'],
    emptyColor: '#e0e0e0',
    strokeColor: '#212121',
    colorFunction: (colors, index) => colors[(index % colors.length)],
    onMouseEnter: item => item,
    onClick: item => item
};
