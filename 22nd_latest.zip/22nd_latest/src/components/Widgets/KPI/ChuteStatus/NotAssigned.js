import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';

import NotAssigned from 'Assets/img/Not_assigned_icon.png';

// intl messages
import IntlMessages from 'Util/IntlMessages';

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/chuteStatusJson.json';

const content = {
	    paddingLeft: '15px',
	    textAlign: 'left'
}

const imageGrid = {
		padding: '5px'
};

const parentGrid = {
		padding: '10px 12px 12px 38px'
};

class index extends Component { 
	render() { 
		return (
				 <Grid style={parentGrid} container>
				 	<Grid style={imageGrid} item xs={3} sm={3}> <img src={NotAssigned} className="assigned" /> </Grid>
				 	<Grid style={content} item xs={9} sm={9}>
					 	<Grid item xs={12} sm={12} style={{fontSize: '24px'}}> {<IntlMessages id={`indvlSoterDashbrd.${json.container.leftSegment.components[2].options.title}`} />} </Grid>
					 	<Grid item xs={12} sm={12} style={{fontSize: '24px'}}> {this.props.value} </Grid>
					</Grid>
				 </Grid>
		);}
}
export default index;