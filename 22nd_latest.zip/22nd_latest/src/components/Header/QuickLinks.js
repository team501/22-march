/**
 * Quick Links
 */
import React from 'react';
import { UncontrolledDropdown, DropdownToggle, DropdownMenu } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { Link } from 'react-router-dom';
import { Badge } from 'reactstrap';
import Tooltip from '@material-ui/core/Tooltip';
import { withRouter } from "react-router-dom";

// helpers
import { getAppLayout } from "Helpers/helpers";

// intl messages
import IntlMessages from 'Util/IntlMessages';

import Settings from '../../assets/img/Setting_icon.png';
import User from '../../assets/img/User_icon.png';
import Bell from '../../assets/img/Bell_icon.png';
import Menu from '../../assets/img/menu_icon.jpg';
import Close from '../../assets/img/close.jpg';
import Dashboard from '../../assets/img/dashboard_icon.jpg';
import BalanceLbr from '../../assets/img/balanceLabor_icon.jpg';
import Equipment from '../../assets/img/equipment_icon.jpg';
import ManageInvt from '../../assets/img/manageInventory_icon.jpg';
import ManageOrdr from '../../assets/img/manageOrder_icon.jpg';
import Reports from '../../assets/img/reports_icon.jpg';
import WorkMonitoring from '../../assets/img/workMonitoring_icon.jpg';
import Exception from '../../assets/img/exception_icon.jpg';

const userName = localStorage.getItem("user_id");




const QuickLinks = ({ location }) => (
	<UncontrolledDropdown nav className="list-inline-item quciklink-dropdown tour-step-1 menu-icon">
		<DropdownToggle nav className="header-icon p-0 hambergerIcon">
			<Tooltip title="Quick Links" placement="bottom">
				<i className="zmdi zmdi-storage"></i>
			</Tooltip>
		</DropdownToggle>
		<DropdownMenu className="drop-downLayout-landing">
			<Scrollbars className="rct-scroll" autoHeight autoHeightMin={100} autoHeightMax={350}>
				<div className="dropdown-content">
					<div className="dropdown-top d-flex justify-content-between rounded-top bg-primary">
						<span className="text-white font-weight-bold">Quick Links</span>
						
					</div>
					<ul className="list-unstyled mb-0 dropdown-list">
						<li>
							<Link to={`#`}>
							<img src={Dashboard} className="image"/>
								<IntlMessages id="LandingPage.dashboard" />
							</Link>
								
						</li>
						<li>
							<Link to={`#`}>
							<img src={BalanceLbr} className="image"/>
								<IntlMessages id="LandingPage.BalanceLabour" />
							</Link>
						</li>
						<li>
							<Link to={`#`}>
							<img src={WorkMonitoring} className="image"/>
								<IntlMessages id="LandingPage.WorkMonitoring" />
							</Link>
						</li>
						<li>
							<Link to={`#`}>
							<img src={Exception} className="image"/>
								<IntlMessages id="LandingPage.Exceptions" />
							</Link>
						</li>
						<li>
							<Link to={`#`}>
							<img src={ManageOrdr} className="image"/>
								<IntlMessages id="LandingPage.ManageOrderWaves" />
							</Link>
						</li>
						<li>
							<Link to={`/app/dashboard/manageEquipment`}>
							<img src={Equipment} className="image"/>
								<IntlMessages id="LandingPage.ManageEquipment" />
							</Link>
						</li>
						<li>
							<Link to={`#`}>
							<img src={ManageInvt} className="image"/>
								<IntlMessages id="LandingPage.ManageInventory" />
									</Link>
						</li>
						<li>
							<Link to={`#`}>
							<img src={Reports} className="image"/>
								<IntlMessages id="LandingPage.Report" />
							</Link>
						</li>

					</ul>
				</div>
			</Scrollbars>
		</DropdownMenu>
	</UncontrolledDropdown>
);

export default withRouter(QuickLinks);
